<html>
    <head>
	   <title>Hello World</title>	
	</head>

	<body> 
	   
	   <?php
	     $i = 1;
		 while($i <= 7)
		 {
			 echo $i." ";
             $i++;			 
		 }
		 
		 
	     	     
	   ?>
	  
	</body>
	
</html>