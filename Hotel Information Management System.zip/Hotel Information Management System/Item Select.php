<!DOCTYPE html>

<?php
//make sql connection
mysql_connect('localhost','root','d@rk1995');

//connect to database
mysql_select_db('hotelmania');
$sql_hotel = "select * from hotel_info";

$rec = mysql_query($sql_hotel);

?>

<html>
    <head>
        <title>My Web</title>
		<link rel="stylesheet" type="text/css" href="Item Select.css">
        <link rel = "stylesheet" type = "text/css" href = "mystyle.css"/>
        <link href='https://fonts.googleapis.com/css?family=Atma' rel='stylesheet'>		
    </head>
    <body>

        <div class = "container dark" id = "top_div">
			    <div class = "wrapper">
			    <div id = "left"> 
				   <h1>Hotelmania.com Be Smart,Book Smart</h1>
				</div>
				<!--<div id = "right"> 
				   <a href = "signin.php">Sign In</a>
                   <a href = "signup.php">Sign Up</a>				   
				</div> -->
				</div>
			</div>
			
			<div class = "container semidark">
			   <div id = "logo_left">
			       <img src = "image/hl.png" alt = "Hotel1 Logo" style = "width:300px;height:100px;">
			   </div>			
			   <div id = "logo_right">
			       <img src = "image/swash.png" alt = "Hotel2 Logo" style = "width:300px;height:100px;">
			   </div>			   
			</div>
			    <!-- <div id = "tslide">
				    <h1><marquee>Welcome to Hotelmania</marquee></h1>
                </div> --> 

                 <div id = "tslide">
				    <h1><marquee bgcolor = "#9C907B">******* Welcome to Hotelmania, Be Smart Book Smart *******</marquee></h1>
                 </div>

				
			<div class = "container">
			     <div class = "wrapper">
				    <div id = "slider">
				    <ul>
		               <li><a href = "front.php">HOME</a></li>
		               <li>
		                  <a href = "">Our Services</a>
		            <ul>
			            <li><a href = "Item Select.php">Platinum</a></li>
		                <li><a href = "Item Select.php">Premium</a></li>
		                <li><a href = "Item Select.php">Regular</a></li>
				        <li><a href = "Item Select.php">Single</a></li>			
			        </ul>
		                </li>
		                <li><a href = "details.php">Photo Gallery</a></li>
		                <li><a href = "booking_form.php">Booking</a></li>
		            </ul>
					</div>
				 </div>
			</div>
		
        <div class="dropdown">
            <button class="dropbtn">Search Tourist Places</button>
            <div class="dropdown-content">
                <a href="#">Cox's Bazar</a>
                <a href="#">St. Martin's Island</a>
                <a href="#">Bandarban</a>
                <a href="#">Sajek Valley</a>
                <a href="#">Sundarban</a>
                <a href="#">Kuakata Sea Beach</a>
            </div>
        </div>
		
        <div class="products">

            <ul>
			
			<?php
		
		        while($student = mysql_fetch_assoc($rec)){
			
		            echo "<li>";
					$proDuct = "product";
					$loc = "details.php";
					$cls1 = "img";
					$cls2 = "name";
                    echo "<div class = $proDuct>";
					echo "<a href = $loc class = $cls1>";
		            echo "<img src = ".$student['picture'].">";					
					echo "</a>";
					echo "<a href = $loc class = $cls2>".$student['location']."</a>";
					echo "</div>";
					echo "</li>";
						
		        }
				
		    ?>
                <!--<li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Mermaid Beach Resort, Cox's Bazar.png"> 	
                        </a>

                        <a href="#" class="name">Mermaid Beach Resort, Cox's Bazar</a>

                    </div>
                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Honey Moon FIJI Resorts.png"> 	
                        </a>

                        <a href="#" class="name">Honey Moon FIJI Resorts</a>

                    </div>
                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Best Western Plus Heritage.png"> 	
                        </a>

                        <a href="#" class="name">Best Western Plus Heritage</a>

                    </div>
                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Royal Tulip Sea Pearl Beach Resort & Spa.png"> 	
                        </a>

                        <a href="#" class="name">Royal Sea Pearl Beach Resort & Spa</a>

                    </div>
                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Seagull Hotel.png"> 	
                        </a>

                        <a href="#" class="name">Seagull Hotel</a>

                    </div>
                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Cox's Bazar Surf Club.png"> 	
                        </a>

                        <a href="#" class="name">Cox's Bazar Surf Club</a>

                    </div>

                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/White Orchid.png"> 	
                        </a>

                        <a href="#" class="name">White Orchid</a>

                    </div>

                </li>
                <li>
                    <div class="product">

                        <a href="#" class="img">
                            <img src="Images/Fu-Wang Dominous Resort.png"> 	
                        </a>

                        <a href="#" class="name">Fu-Wang Dominous Resort</a>
                    </div>
                </li> -->								
				
            </ul>
        </div>
		
		<div class = "container dark">
			    <div class = "wrapper">				    
					     <div id = "footer_section"> 
					      <h2>Latest News 1</h2>		
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>
            						 															
					     <div id = "footer_section"> 
					      <h2>Latest News 2</h2>		
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>
            						 										
					     <div id = "footer_section"> 
					      <h2>Latest News 3</h2>			
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>           						 				
				 </div>						
			</div>

    </body>
</html>