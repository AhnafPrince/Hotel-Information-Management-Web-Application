<!DOCTYPE html>

<html>
         <head>
             <title>My Web</title>
			 <link rel = "stylesheet" type = "text/css" href = "mystyle.css"/>
			 <link href='https://fonts.googleapis.com/css?family=Atma' rel='stylesheet'>
			 <script src = "jquery-3.2.1.min.js" type "text/javascript"></script>
             <script src = "jquery.cycle.all.js" type "text/javascript"></script>
			 <script type "text/javascript">
			     $(document).ready(function()
				 {
				    $('#image').cycle({     fx:    'fade',     speed:  2500 });
				 }
				 );
				 
				 $(document).ready(function()
				 {
				    $('#bleft_image').cycle({     fx:    'fade',     speed:  2500 });
				 }
				 );
				 
			 </script>
         </head>
		 
		 
		 <body>
		    <div class = "container dark" id = "top_div">
			    <div class = "wrapper">
			    <div id = "left"> 
				  <h1>Hotelmania.com Be Smart,Book Smart</h1>
				</div>
				<!--<div id = "right"> 
				   <a href = "signin.php">Sign In</a>
                   <a href = "signup.php">Sign Up</a>				   
				</div> -->
				</div>
			</div>
			
			<div class = "container semidark">
			   <div id = "logo_left">
			       <img src = "image/hl.png" alt = "Hotel1 Logo" style = "width:300px;height:100px;">
			   </div>			
			   <div id = "logo_right">
			       <img src = "image/swash.png" alt = "Hotel2 Logo" style = "width:300px;height:100px;">
			   </div>			   
			</div>
			    <div id = "tslide">
				    <h1><marquee bgcolor = "#9C907B">******* Welcome to Hotelmania, Be Smart Book Smart *******</marquee></h1>
                </div>	
			<div class = "container">
			     <div class = "wrapper">
				    <div id = "slider">
				    <ul>
		               <li><a href = "">HOME</a></li>
		               <li>
		                  <a href = "">Our Services</a>
		            <ul>
			            <li><a href = "Item Select.php">Platinum</a></li>
		                <li><a href = "Item Select.php">Premium</a></li>
		                <li><a href = "Item Select.php">Regular</a></li>
				        <li><a href = "Item Select.php">Single</a></li>			
			        </ul>
		                </li>
		                <li><a href = "details.php">Photo Galary</a></li>						      													  						
		                <li><a href = "booking_form.php">Booking</a></li>
		            </ul>
					</div>
				 </div>
			</div>
			
			<div class = "container light">
			    <div class = "wrapper">
				    <div id = "image">
					      <img src = "image/Hotel/hotel.jpg">
					      <img src = "image/Hotel/hotel2.jpg">
						  <img src = "image/Hotel/hotel3.jpg">
						  <img src = "image/Hotel/hotel4.jpg">
					</div>
				 </div>						
			</div>
			
			<div class = "container">
			    <div class = "wrapper">
				     <div id ="text_image">
					      <img src = "image/welcome.png" alt = "Welcome" style = "width:120px;height:120px;">
					 </div>
				    <h3>Welcome To Our Website</h3>
					<p>
					     Pretty hotel. They started to charge for parking!!! (This was not notify earlier in the booking) They give us room keys that don't work. 
						 ( happens more than one time) The walls don't cancel noise. I could still hear other people talking and in the middle of night. Placed unauthorized
						 charge on the room for no good reason. Had to call to Ask the staff to make it correct, took very long time. Bad attitude also at one point they hung
						 up on us. Iineffective staff that's was rude made the stay even more frustrating. Buffet quality of food, taste and atmosphere had lower dramatically!!!!!
					</p>
					
					 <div id ="dtext">
					    <h3>Our Services</h3>
					     <p>
					     Pretty hotel. They started to charge for parking!!! (This was not notify earlier in the booking) They give us room keys that don't work. 
						 ( happens more than one time) The walls don't cancel noise. I could still hear other people talking and in the middle of night. Placed unauthorized
						 charge on the room for no good reason. Had to call to Ask the staff to make it correct, took very long time. Bad attitude also at one point they hung
						 up on us. Iineffective staff that's was rude made the stay even more frustrating. Buffet quality of food, taste and atmosphere had lower dramatically!!!!!
						 I loved the décor, most of the staff, and conservatory. The show (O) was great too! We had a couple of issues with staff, the main on being the guy who "checked"
						 the keys before entering the elevators was rude and not at all consistent with who he checked (both in our favor and against). When my husband asked him about it 
						 he was combative and obnoxious.
					     </p>					    
					 </div>
					 
					 <div id ="dtext">
					    <h3>Services</h3>
					     <p>
					     Pretty hotel. They started to charge for parking!!! (This was not notify earlier in the booking) They give us room keys that don't work. 
						 ( happens more than one time) The walls don't cancel noise. I could still hear other people talking and in the middle of night. Placed unauthorized
						 charge on the room for no good reason. Had to call to Ask the staff to make it correct, took very long time. Bad attitude also at one point they hung
						 up on us. Iineffective staff that's was rude made the stay even more frustrating. Buffet quality of food, taste and atmosphere had lower dramatically!!!!!
						 I loved the décor, most of the staff, and conservatory. The show (O) was great too! We had a couple of issues with staff, the main on being the guy who "checked"
						 the keys before entering the elevators was rude and not at all consistent with who he checked (both in our favor and against). When my husband asked him about it 
						 he was combative and obnoxious.
					     </p>					    
					 </div>
					 
					 <div id ="dtext">
					    <h3>Services</h3>
					     <p>
					     Pretty hotel. They started to charge for parking!!! (This was not notify earlier in the booking) They give us room keys that don't work. 
						 ( happens more than one time) The walls don't cancel noise. I could still hear other people talking and in the middle of night. Placed unauthorized
						 charge on the room for no good reason. Had to call to Ask the staff to make it correct, took very long time. Bad attitude also at one point they hung
						 up on us. Iineffective staff that's was rude made the stay even more frustrating. Buffet quality of food, taste and atmosphere had lower dramatically!!!!!
						 I loved the décor, most of the staff, and conservatory. The show (O) was great too! We had a couple of issues with staff, the main on being the guy who "checked"
						 the keys before entering the elevators was rude and not at all consistent with who he checked (both in our favor and against). When my husband asked him about it 
						 he was combative and obnoxious.
					     </p>					    
					 </div>
					
					
				 </div>						
			</div>
			
			<div class = "container light">
			    <div class = "wrapper">
				    <div id = "bottom_left">
					    <h3 id = "bleft_text">More Information</h3>
						 <div id = "bleft_image">
						 <img src = "image/Hotel/hotel.jpg" alt = "Info Pic 1" align = "left">
					     <img src = "image/Hotel/hotel2.jpg" alt = "Info Pic 2" align = "left">
						 <img src = "image/Hotel/hotel3.jpg" alt = "Info Pic 3" align = "left">
						 <img src = "image/Hotel/hotel4.jpg" alt = "Info Pic 4" align = "left">
						 </div>
						 <p>
					     Pretty hotel. They started to charge for parking!!! (This was not notify earlier in the booking) They give us room keys that don't work. 
						 ( happens more than one time) The walls don't cancel noise. I could still hear other people talking and in the middle of night. Placed unauthorized
						 charge on the room for no good reason. Had to call to Ask the staff to make it correct, took very long time. Bad attitude also at one point they hung
						 up on us. Iineffective staff that's was rude made the stay even more frustrating. Buffet quality of food, taste and atmosphere had lower dramatically!!!!!
						 I loved the décor, most of the staff, and conservatory. The show (O) was great too! We had a couple of issues with staff, the main on being the guy who "checked"
						 the keys before entering the elevators was rude and not at all consistent with who he checked (both in our favor and against). When my husband asked him about it 
						 he was combative and obnoxious.
						 </p>
					</div>
					
					<div id = "bottom_right">
					      <div id = "latest_news"> 
					      <h2>Latest News 1</h2>
					      <img src = "image/Hotel/hotel.jpg" alt = "Info Pic" align = "left">
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
						 </div>
						 
						 <div id = "latest_news"> 
					      <h2>Latest News 2</h2>
					      <img src = "image/Hotel/hotel2.jpg" alt = "Info Pic" align = "left">
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
						 </div>
						 
						 <div id = "latest_news"> 
					      <h2>Latest News 3</h2>
					      <img src = "image/Hotel/hotel3.jpg" alt = "Info Pic" align = "left">
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
						 </div>
					</div>
					
					<div id = "clear">					  
					</div>
					
				 </div>						
			</div>			
			
			<div class = "container dark">
			    <div class = "wrapper">				    
					     <div id = "footer_section"> 
					      <h2>Latest News 1</h2>		
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>
            						 															
					     <div id = "footer_section"> 
					      <h2>Latest News 2</h2>		
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>
            						 										
					     <div id = "footer_section"> 
					      <h2>Latest News 3</h2>			
						  <p>
					         Pretty hotel. They started to charge for parking!! They give us room keys that don't work. 						 
						 </p>
					  	 </div>           						 				
				 </div>						
			</div>
						
		 </body>
		 
</html>