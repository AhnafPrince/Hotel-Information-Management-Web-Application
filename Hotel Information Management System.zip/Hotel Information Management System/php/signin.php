<!DOCTYPE html>

<html>
     <head>
	      <title>Login Form</title>
		  <link rel = "stylesheet" type = "text/css" href = "style1.css"/>
         <!-- <link rel = "stylesheet" type = "text/css" href = "font-awesome.css"/>  -->
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">  		 
     </head>

     <body>
	      <div id ="back">
		     <a href = "front.html">Back</a>
		  </div>
	     <div class = "contain">
		    <img src = "images/people.png"/>
		    <form>
			     <div class = "form-input">
				     <input type = "text" name ="username" placeholder = "Enter Username">
				 </div>
				 <div class = "form-input">
				     <input type = "password" name = "password" placeholder = "Enter Password">
				 </div>
				     <input type = "submit" name = "sign_in" value = "LOGIN" class = "btn-login">
            </form>
			      <a href = "signup.php">Sign Up Now!</a></br></br>
                  <a href = "#">Forget Password?</a>  			
		 </div> 
     </body>

</html>